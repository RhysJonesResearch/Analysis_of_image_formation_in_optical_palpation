workDir = 'F:\Rhys\AbaqusModels\COP_Workspace'
inpPath = 'F:\\Rhys\\COP_Outputs\\231104_Inc_5_5mm3_10p_highres_sig7.inp'
dataName = '231104_Inc_5_5mm3_10p_highres_sig7'
RAM = 10
