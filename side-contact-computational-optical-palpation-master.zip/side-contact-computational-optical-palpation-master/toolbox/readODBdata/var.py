filepath = 'F:\Rhys\AbaqusModels\COP_Workspace'
filename = '231104_Inc_5_5mm3_10p_highres_sig7'
instance = 'LAYERASSEMBLY'
step = 'Preload'
frame = -1
