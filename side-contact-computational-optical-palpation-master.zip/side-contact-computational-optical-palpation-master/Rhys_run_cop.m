%% Example script for computational optical palpation
% Add to path
% addpath(genpath('../computational-optical-palpation/'));

%% User Input
% Meta data
meta.job = 'Confined_BC_test_sides';
meta.model = 'Model-1';
meta.gen = 'computational QOCE toolbox';
meta.output_path =  'F:\Rhys\COP_Outputs';
meta.abaqus_work_dir = 'F:\Rhys\AbaqusModels\COP_Workspace';
% Thickness data
L0 = 5.318;
load('F:\Rhys\MATLAB Workspace\230825_Inc_2_Flat_5mm2\230825_Inc_2_Flat_5mm2_5p\LTImage.mat');
%Lp3 = 1.0-2*abs(0.5-in_L0);
% Material
material.C10 = 0.0022;
material.C01 = 7.03E-4;
% Meshing
opt.size = [15.5,15];
opt.mesh.mesh_type = 'hex';
opt.mesh.elem_type = 'C3D8';
opt.mesh.mesh_size = 0.5;
% Friction
opt.frict.plate = 0.15;
opt.frict.sample = 0.001;
% Interaction Properties
opt.int.weight.plate = 0.5;
opt.int.weight.sample = 0.5;

%% Run COP
[T] = main_cop_explicit( meta, L0, Lp3, material, opt ); % Need to define layer side contacts to plates

%% Visualise Results
figure;imagesc(T);colormap(gray(256));
save('F:\Rhys\MATLAB Workspace\Tvar','T');
