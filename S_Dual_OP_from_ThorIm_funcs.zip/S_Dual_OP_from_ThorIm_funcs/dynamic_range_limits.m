function [out_min, out_max] = dynamic_range_limits(img, sigma, exclude_z, nominal_range, min_range_limit)
%% [out_min, out_max] = dynamic_range_limits(img, sigma, exclude_z, nominal_range, min_range_limit)
% Returns the minimum and maximum OCT DB which can be used to clip the
% given image such that the final dynamic range matches the specified
% nominal_range.
%
% img: input OCT image in (z, x) coordinates
%
% sigma: standard deviation in pixels of the Gaussian smoothing kernel
% used to filter the image before estimating the dynamic range.
%
% exclude_z: z-idxs of pixels to exclude from the calculation, usually
% because they contain extraneous noise.
%
% nominal_range: the dynamic range to try to match.
%
% min_range_limit: [min, max] the minimum and maximum limits of the
% out_min parameter. Usually min is set to 0, so that the OCT image
% never reaches below 0 dB, and max is set to some number such that very
% bright points in the OCT image won't cause the entire image to be
% clipped to 'black'.
%
%
% out_min, out_max: values which can then be used to clip the OCT image.

% Smoothing kernel for determining the OCT dynamic range
gauss = fspecial('gaussian', 8*ceil(sigma), sigma);

% Smooth the input before calculating dynamic range
smoothed_img_zx = imfilter(img, gauss, 'symmetric');

% Exclude particular z-values
smoothed_img_zx(exclude_z, :) = min(smoothed_img_zx(:));

% Set the DBRange to a fixed dynamic range based on the max DB
out_max = round( max(smoothed_img_zx(:)) );
% Clip out_min based on the specified limits, min_range_limit
out_min = max(out_max - nominal_range, min(min_range_limit));
out_min = min(out_min, max(min_range_limit));

% RHYS WANTING TO SATURATE
%out_max = min(out_max, out_min + nominal_range);

end
