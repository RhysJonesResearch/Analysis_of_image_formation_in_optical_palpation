function LayerThickness_x = sigmoid_fit(img, config, UorC)
%% Goal - Fit sigmoid to edge to find transition pixel instead of using Canny stages 1 and 2
%%
if UorC == 0
    Z_u = config.EXTENT_Z_u(1);
    Z_l = config.EXTENT_Z_u(2);
else
    Z_u = config.EXTENT_Z_c(1);
    Z_l = config.EXTENT_Z_c(2);
end
cutoff = 12;

LayerThickness_x = zeros([size(img,1),1]);

img_z = img(Z_u:Z_l,:);

img_z = stdfilt(img_z,true(7));
img_z = imgaussfilt(img_z,[3 7]);
% img_z = imgaussfilt(img_z,[1 5]);
% img_z = medfilt2(img_z,[3 3]);
% img_z = imgaussfilt(img_z,[1 3]);

if config.NoHist == 0
    [N,edges] = histcounts(img_z,100);
    x_s = double((edges(1:end-1)+edges(2:end))/2);
    N = double(N);
    [~,locs,~,~] = findpeaks(N,x_s,'SortStr','descend');
    peaks_T = [locs(1), locs(2)];
end
PixNum = 1:Z_l-Z_u-cutoff+1;
% PixNum = 1:Z_l-Z_u-cutoff+1;
% %step = [zeros(1,floor(size(PixNum,2)/2))+min(peaks),zeros(1,ceil(size(PixNum,2)/2))+max(peaks)];
% step = [zeros(1,floor(size(PixNum,2)*2))+min(peaks),zeros(1,ceil(size(PixNum,2)*2))+max(peaks)];

for n2 = 1:size(img_z,2)
    col = img_z(1:end-cutoff,n2);
    
    if config.NoHist == 1
            peaks = [mean(col(1:config.NoHistW)),mean(col((size(col,1)-config.NoHistW):size(col,1)))];
    else
        [N,edges] = histcounts(col,100);
        x_s = double((edges(1:end-1)+edges(2:end))/2);
        N = double(medfilt1(N,4));
        N = double(imgaussfilt(N,config.HistFilt));
        [p,locs,~,~] = findpeaks([0,N,0],[min(x_s)-1,x_s,max(x_s)+1],'SortStr','none','MinPeakProminence',1.0);
        if size(locs,2) > 1   
            if abs(max(locs) - max(col)) < 0.01 && p(end) < 2
                locs = locs(1:end-1);
            end
        end
        if min(locs) == max(locs) && n2 > 1
            % do nothing and hence set to previous peaks values
        else
            peaks = [min(locs), max(locs)];
        end
%         if size(locs,2) >=2 && abs(locs(1)-locs(2)) > 0.3
%             peaks = [locs(1), locs(2)];
%         elseif size(locs,2) >=3 && abs(locs(1)-locs(3)) > 0.3
%             peaks = [locs(1), locs(3)];
%         elseif size(locs,2) >=4 && abs(locs(1)-locs(4)) > 0.3
%             peaks = [locs(1), locs(4)];
%         elseif n2 > 1
%             % do nothing and hence set to previous peaks values
%         else
%             peaks = peaks_T;
%         end
    end
    
    step = [zeros(1,floor(size(PixNum,2))-config.InterFlatW)+min(peaks),zeros(1,config.InterFlatW)+min(peaks)+config.InterFlatM*(max(peaks)-min(peaks)),zeros(1,config.InterfacePeakW)+max(peaks)+config.InterfacePeakM*(max(peaks)-min(peaks)),zeros(1,ceil(size(PixNum,2))-config.InterfacePeakW)+max(peaks)];
    col2 = [zeros(1,floor(size(PixNum,2)*2))+min(peaks),col',zeros(1,floor(size(PixNum,2)*2))+max(peaks)];
    [r,lags] = xcorr(col2-mean(peaks),step-mean(peaks));
    [~, idx] = max(r);
    LayerThickness_x(n2) = Z_u - floor(size(PixNum,2)) + lags(idx);
end

figure
imagesc(img)
caxis('auto');
colorbar;
colormap gray;
hold on;
plot(LayerThickness_x, 'r-');

end