function layer_z = detect_layer_stage1(bw, nm)
%% layer_z = detect_layer_stage1(bw, nm)
% Initial guess as to the stress layer surface. Takes in (bw) images of
% the detected edge surfaces from the Canny-based detector in
% canny_stage1 and canny_stage2, and (nm) the strength of those edge
% pixels.
%
% Returns a vector of the z-index of the stress layer surface at each
% x-index. The z-index will be NaN if there is no detected layer in that
% pixel.
%import OCT_OCE.Layer.minimum_distance;

SizePixX = size(bw, 2);

% Bridge single pixel gaps (very common with this edge detector)
bridged_bw = bwmorph(bw, 'bridge');

% % DEBUG
% figure
% imagesc(bridged_bw)
% caxis('auto')
% colorbar

%% Algorithm for picking the best segments
% Find the largest segment, and supress the points above and below this
% segment. Add this segment to the list, removing it from the edge
% detected image. Continue until there are no more segments
good_seg_lin_idxs = {};
while ~isempty(find(bridged_bw, 1))
    % 'Label' each connected segment in order to find the largest segments
    labeled_bw = bwlabel(bridged_bw, 8);

    % Count the number of pixels in each labeled segment. NB: the +1 is
    % because labelled starts from 0, but the first argument to
    % accumarray() needs to be a set of matlab array indices, which
    % start from 1.
    labeled_counts = accumarray(labeled_bw(:)+1, 1);
    % idx = 1 is the background, label = 0, which isn't interesting
    labeled_counts = labeled_counts(2:end);

    % What's the largest segment?
    longest_size = max(labeled_counts);
    seg_nums = find( labeled_counts == longest_size );

    if numel(seg_nums) == 1
        % only one segment fits the bill, so this is our detected edge
        strongest_seg = seg_nums;
    elseif numel(good_seg_lin_idxs) == 0
        % this is the very first segment in this bscan, so we don't have
        % any previously selected segments. Just pick one and hope for the
        % best
        strongest_seg = seg_nums(1);
    else
        % else, find the segment which is closest (euclidean distance) from the
        % already selected segments
        selected_lin_idxs = cat(1, good_seg_lin_idxs{:});
        [ sel_z, sel_x ] = ind2sub(size(labeled_bw), selected_lin_idxs);
        P = [sel_x, sel_z];
        min_dist = inf( size(seg_nums) );
        for seg_idx = 1:numel(seg_nums)
            [this_seg_z, this_seg_x] = find(labeled_bw == seg_nums(seg_idx));
            Q = [this_seg_x, this_seg_z];
            min_dist(seg_idx) = minimum_distance(P, Q);
        end
        [~, min_idx] = min(min_dist);
        strongest_seg = seg_nums(min_idx);
    end

    lin_idx = find(labeled_bw == strongest_seg);
    [~, tmp_x] = ind2sub(size(labeled_bw), lin_idx);

    % Add the linear addresses of this segment to the list
    good_seg_lin_idxs{end+1} = lin_idx;
    % And remove this segment from the map of intial edge points
    bridged_bw(:, tmp_x) = 0;
end

% Found the 'best' connected segment in each x-location
selected_idxs = cat(1, good_seg_lin_idxs{:});
[tmp_z, tmp_x] = ind2sub(size(bw), selected_idxs);

% Now go through each x location to find the best edge pixel, since it
% could have multiple pixels that are selected at a particular x
% location
layer_z = NaN(SizePixX, 1);
for x_idx = 1:SizePixX
    % find the labeled pixels in this x-location
    labeled_z_idxs = tmp_z(tmp_x == x_idx);
    if isempty(labeled_z_idxs)
        % no labeled edge detected pixels, skip it
        continue;
    end
    if numel(labeled_z_idxs) == 1
        % only one pixel fits the bill, so this is our detected edge
        layer_z(x_idx) = labeled_z_idxs;
    else
        % find the pixel with the strongest initial edge response
        edge_resp = nm(labeled_z_idxs, x_idx);
        [~, e_idx] = max(edge_resp);
        layer_z(x_idx) = labeled_z_idxs(e_idx);
    end
end

% % DEBUG
% figure
% plot(-layer_z)
% xlim([0 1000])
% ylim([-1024 0])
% colorbar
end

