function filtered_z = detect_layer_stage2(layer_z)
%% filtered_z = detect_layer_stage2(layer_z)
% Refine the guess as to the stress layer surface. This uses
% interpolation to guess the stress layer locations at NaNs within the
% detected layer surface, and hampel() filtering to try to eliminate
% outliers in the detected surface pixels.

% Now interpolate within the detected layer to estimate places with no
% detected edge. DON'T extrapolate, since this causes really crazy
% values at the edges of the sample, plus we could be imaging off the
% edge of the imaging window, in which case there won't be any signal to
% detect anyway.
%import OCT_OCE.Layer.hampel;

good_idxs = find(~isnan(layer_z));
x = 1:numel(layer_z);
filtered_z = nan(size(x));
if numel(good_idxs >= 2)
    inter_z = interp1(good_idxs, layer_z(good_idxs), x, 'linear');
    
%     % DEBUG
%     figure
%     plot(-inter_z)
%     xlim([0 1000])
%     ylim([-1024 0])
%     colorbar

    % Filter out crap pixels when the detected edge jumps too far. Try this
    % using the adaptive hampel filter which seems to work very well for
    % this purpose
    % filtered_z = hampel(x, inter_z, 3, 3, 'adaptive', 0.1);
    filtered_z = hampel(x, inter_z, 4, 0.1, 'adaptive', 0.1);
    
%     % DEBUG
%     figure
%     plot(-filtered_z)
%     xlim([0 1000])
%     ylim([-1024 0])
%     colorbar
end

% [filtered_z, idx, Y0, LB, UB, ADX, num_outliers] = hampel(x, inter_z, 3, 3, 'adaptive', 0.1);
% figure;
% plot(layer_z, 'b.'); hold on; % Original Data
% plot(filtered_z, 'r');                % Hampel Filtered Data
% plot(Y0, 'b--');              % Nominal Data
% plot(LB, 'r--');              % Lower Bounds on Hampel Filter
% plot(UB, 'r--');              % Upper Bounds on Hampel Filter
% plot(x(idx), layer_z(idx), 'ks'); % Identified Outliers
% set(gca, 'YDir', 'rev')

end

