
function intensity = loadSSOCT(ssoct_name, size)

%% This function loads the processed log-scale OCT intensity data.
%
% Inputs:
%         ssoct_name: the filename of the intensity data.
%         size:       size of the 3D data volume in pixel for X, Y and Z directions.
%
% Output:
%         intensity: the processed OCT intensity data.
%
% Peijun Gong, 2014.03.18

%% (1) Load the processed structure OCT data.

% Open the intensity data.
fid_inten = fopen(ssoct_name, 'rb');

% If the intensity data can't be opened, stop running.
if (fid_inten == -1)
    error( ['Failed to open data file: ' ssoct_name] );
end

% Locate the beginning of the intensity data.
fseek(fid_inten, 0, 'bof');

% Calculate the number of pixels in a frame.
frame_pixel_num = size(1)*size(3);

% Preallocate the space for the 3D data volume.
intensity = zeros( size(1),  size(2),  size(3), 'single');

% Load all the frames.
for y_idx = 1: size(2)
    
    frame_2D = fread(fid_inten, frame_pixel_num, 'single');
    frame_2D = reshape(frame_2D,  size(3),  size(1));
    intensity(:, y_idx, :) = frame_2D';
    
end

% Close the data file.
close_status = fclose(fid_inten);

% Display the close operation status. 
if (close_status == 0)
    display('The intensity data file has been successfully closed.');
else
    display('Warning: the intensity data file can not be closed!!!');
end

end

%% End of the function.
