function LayerThickness_x = oct_find_surface(OCT_Bscan_zx, config)
%% LayerThickness_x = oct_find_surface(OCT_Bscan_zx, config)
% Finds the pixel co-ordinates of the tissue surface or stresslayer
% boundary for the whole B-scan, given the specified parameters. NOTE:
% result can be in fractions of a pixel.
%
% OCT_Bscan_zx: the oct log-scaled intensity in (z, x) coordinate ordering.
%
% config: configuration structure to control the surface detection code.
%
% config.EXTENT_Z = [min, max]: if EXTENT_Z is specified, it is the Z-extent in 
% *pixels* over which to look for the surface. 
% In general, set this to exclude the first few z-pixels to avoid
% issues from the DC noise at the surface, and the last few z-pixels to avoid a
% strong parasitic back reflection at around this depth.
% If it is set to -1, then it allows for user selection of freehand ROI 
% around the layer-sample interface.
%
% config.OCT_NOMINAL_DYNAMIC_RANGE = val: Clip the OCT SNR to approximately this
% dynamic range in DB
%
% config.OCT_MIN_DB_RANGE = [min, max]: When clipping the OCT SNR, limit the
% minimum OCT SNR to be within this range. This is to try to suppress the
% speckle noise within the transparent stress layer
%
% config.OCT_SIGMA = val: Standard deviation of the smoothing filter used to
% estimate the OCT dynamic range (in pixels)
%
% config.EDGE_SIGMA = val: Standard deviation of the smoothing filter for the
% Canny-based edge detector (in pixels)
%
% config.PERCENT_PIX_NOT_EDGES = val: Approximate proportion [0, 1] of pixels in
% each B-scans which are *not* edge pixels. For the breast QOCE taken on the
% 835nm SD-OCT system, this seems to work best as 0.7. For the Skin / phantom
% data taken on the 1300nm Telesto system, this seems to work best as 0.9.
%
% config.LAYER_OFFSET_Z = val: Pixel offset in z to adjust the final
% location of the stresslayer interface after other processing. For
% 'fat' interfaces, this code can often underestimate (in z) the
% location of the layer. A value of 2/3 * EDGE_SIGMA, or 1 * EDGE_SIGMA
% seems to work reasonably well.
% 
% config.DETECT_NEG_GRAD = val: -1, off, 1, on. If on, edge detection takes
% the negative of the axial gradient and then sets anything less than 0 to
% 0. This means it looks to detect changes from bright to dark instead. Use
% when you want to find the interface between a transparent layer and the
% lubricating oil (if also transparent).
% 
% Based heavily on the 2-D processing in main_stresslayer_thickness.m
%
% Author: Lixin Chin, Andrea Curatolo
% First Release: 3 February 2016
% Second Release: 3 November 2016
%import OCT_OCE.Layer.*;


if config.EXTENT_Z == -1;
    figure
    imagesc(OCT_Bscan_zx);
    caxis([0 50]);
    colorbar;
    colormap gray;
    h = imfreehand;
    position = wait(h); %doubleclick within the selected freehand area to continue execution
    z_idxs = (1:size(OCT_Bscan_zx, 1));
    EXCLUDE_IDX_Z = find((z_idxs <= min(position(:,1))) | ...
        (max(position(:,1)) <= z_idxs));
    EXCLUDE_IDX_ZX = createMask(h);
else
    % Calculate the Z pixels of data to exclude
    z_idxs = (1:size(OCT_Bscan_zx, 1));
    
    EXCLUDE_IDX_Z = find((z_idxs <= config.EXTENT_Z(1)) | ...
        (config.EXTENT_Z(2) <= z_idxs));
    EXCLUDE_IDX_ZX = ones(size(OCT_Bscan_zx,1),1);
    EXCLUDE_IDX_ZX(EXCLUDE_IDX_Z) = 0;
    EXCLUDE_IDX_ZX = repmat(EXCLUDE_IDX_ZX,1,size(OCT_Bscan_zx,2));
end

% Determine the clipping limits of the OCT image based on a desired dynamic
% range
[DBRange_min, DBRange_max] = dynamic_range_limits(...
    OCT_Bscan_zx, ...
    config.OCT_SIGMA, ...
    EXCLUDE_IDX_Z, ...
    config.OCT_NOMINAL_DYNAMIC_RANGE, ...
    config.OCT_MIN_DB_RANGE);

% Clip to the specified range.
OCT_Bscan_zx(OCT_Bscan_zx < DBRange_min) = DBRange_min;
OCT_Bscan_zx(OCT_Bscan_zx > DBRange_max) = DBRange_max;

% DEBUG
% figure
% imagesc(OCT_Bscan_zx);
% caxis([DBRange_min DBRange_max]);
% caxis('auto');
% colorbar;
% colormap gray;

% Find the edge strength and orientation throughout the B-scan using the Canny
% detector.
[magGrad, orGrad] = canny_stage1(OCT_Bscan_zx, config.EDGE_SIGMA, config.DETECT_NEG_GRAD);


% Perform non-maximal suppression and hysteresis thresholding, additionally
% excluding vertical edges, and favouring horizontal edges which occur at dark
% -> bright (as z increases) transitions. Additionally suppress edges at the top
% and bottom of the B-scan.
[bw, nm] = canny_stage2_surface(magGrad, orGrad, EXCLUDE_IDX_ZX, ...
                                'PercentOfPixelsNotEdges', ...
                                config.PERCENT_PIX_NOT_EDGES);

% Use the results of the Canny-based detector to locate an initial estimate for
% the layer surface.
layer_z = detect_layer_stage1(bw, nm);

%% if only one pixel for the layer is found matlab return an error when 
% interpolating layer thickness. the following code counts the number of
% integers in the detected layer and if 0 or 1 assignes a starting and
% ending position for layer interpolation

sum_of_layer_pixels = sum(layer_z==layer_z,1);

if sum_of_layer_pixels < 2
    disp('layer not detected - allocating start and end position for interpolation');
    layer_z(1) = 1;
    layer_z(length(layer_z)) = 1;
end

% Refine the initial estimate by interpolating for non-detected pixels within
% the surface, and filtering out outliers using a hampel() filter.
filtered_z = detect_layer_stage2(layer_z);

% The Canny-based detector tends to underestimate (in z) the location of edges,
% especially 'fat' edges where the stress layer interface presents as a very
% bright, saturated, fat line. It tends to work OK if the sample surface is
% flush with the stresslayer so the interface is more of a step edge. Either
% way, adding a small vertical offset seems to produce quite good results.
%
% For the oce finger probe measurements, disable this offset, since the
% backreflection from the stresslayer/tissue interface is much much less.
LayerThickness_x = filtered_z + config.LAYER_OFFSET_Z;

% If the detected pixels lie outside the valid z-range of the data, then they
% are invalid and should be marked as NaN
LayerThickness_x(LayerThickness_x < 1) = NaN;
LayerThickness_x(LayerThickness_x > size(OCT_Bscan_zx, 1)) = NaN;

% DEBUG
% figure
% imagesc(OCT_Bscan_zx);
% caxis('auto');
% colorbar;
% colormap gray;
% hold on;
% plot(LayerThickness_x, 'r-');
end
