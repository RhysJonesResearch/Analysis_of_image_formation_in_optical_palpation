function [bw, nm] = canny_stage2_surface(magGrad, orGrad, EXCLUDE_IDX_ZX, varargin)
%% [bw, nm] = canny_stage2_surface(magGrad, orGrad, EXCLUDE_IDX_ZX)
% Implements a modified version of the second stage of the Canny edge
% detector, performing non-maximal suppression and hysteresis
% thresholding, but additionally weighting the detected edges to
% suppress vertical edges, and to favour horizontal edges which are
% across dark -> bright regions as z increases in the OCT image.
%
% magGrad, orGrad: outputs from canny_stage1.m
%
% Additionally, take in an optional parameter, EXCLUDE_IDX_ZX, which
% lists the zx-idxes where edges should not occur, which is used to
% suppress suprious detection of edges outside a user-defined area of the OCT
% image.
%
% Returns bw, the hysterisis thresholded edges, and nm, which is the
% non-maximally suppressed edge magnitudes.
%
% V.1.0 2012 Lixin Chin: canny_stage2_surface(magGrad, orGrad, EXCLUDE_IDX_Z)
% V.1.1 2016 Andrea Curatolo: canny_stage2_surface(magGrad, orGrad, EXCLUDE_IDX_ZX)

%import OCT_OCE.Layer.hysthresh;
%import OCT_OCE.Layer.nonmaxsup;

%% Parse and validate the input arguments
p = inputParser;

% Used for selecting thresholds
p.addOptional('PercentOfPixelsNotEdges', 0.7, @(x) (isnumeric(x) && isscalar(x)));
% Low thresh is this fraction of the high.
p.addOptional('ThresholdRatio', 0.4, @(x) (isnumeric(x) && isscalar(x)));
% If empty, automatically determine the thresholds
p.addOptional('Thresholds', [], @(x) isempty(x) || (numel(x) == 2) );

% Parse and validate the optional input arguments.
p.parse(varargin{:})

PercentOfPixelsNotEdges = p.Results.PercentOfPixelsNotEdges;
ThresholdRatio          = p.Results.ThresholdRatio;
thresh                  = p.Results.Thresholds;

% Normalize the edge magnitude for threshold selection
magmax = max(magGrad(:));
if magmax > 0
    magGrad = magGrad / magmax;
end

% Supress vertical edges
scaled_magGrad = magGrad .* sin(orGrad/180*pi);

% % DEBUG
% figure
% imagesc(scaled_magGrad)
% caxis('auto')
% colorbar
% colormap gray

% For non-maximal suppresion, require the angle to be an integer between
% 0 and 180 degrees
orientation_p = orGrad;
orientation_p(orientation_p < 0) = orientation_p(orientation_p < 0) + 180;
orientation_p = round(orientation_p);

% non-maximal suppression of the remaining edges
%nm = nonmaxsup(scaled_magGrad, orientation_p, 1.5);
nm = nonmaxsup(scaled_magGrad, orientation_p, 1.35);

% Supress edges outside the user-defined area Exclude_IDX_ZX
%nm(EXCLUDE_IDX_Z, :) = 0; % Supress edges at the top and bottom
nm = EXCLUDE_IDX_ZX.*nm; 

% % DEBUG
% figure
% imagesc(nm)
% colormap gray
% caxis('auto')
% colorbar

% Determine Hysteresis Thresholds
[lowThresh, highThresh] = selectThresholds(thresh, scaled_magGrad, PercentOfPixelsNotEdges, ThresholdRatio);

% Threshold the non-maximally suppressed edges
bw = hysthresh(nm, lowThresh, highThresh);

% DEBUG
% figure
% imagesc(bw)
% colormap gray
% caxis('auto')
% colorbar
end

%% LOCAL FUNCTIONS
function [lowThresh, highThresh] = selectThresholds(thresh, magGrad, PercentOfPixelsNotEdges, ThresholdRatio)
%% [lowThresh, highThresh] = selectThresholds(thresh, magGrad, PercentOfPixelsNotEdges, ThresholdRatio)
% Select appropriate hysteresis thresholds
[m,n] = size(magGrad);

% Select the thresholds
if isempty(thresh)
    counts=imhist(magGrad, 64);
    highThresh = find(cumsum(counts) > PercentOfPixelsNotEdges*m*n,...
        1,'first') / 64;
    lowThresh = ThresholdRatio*highThresh;
elseif length(thresh)==1
    highThresh = thresh;
    if thresh>=1
        error(message('images:edge:thresholdMustBeLessThanOne'))
    end
    lowThresh = ThresholdRatio*thresh;
elseif length(thresh)==2
    lowThresh = thresh(1);
    highThresh = thresh(2);
    if (lowThresh >= highThresh) || (highThresh >= 1)
        error(message('images:edge:thresholdOutOfRange'))
    end
end

end
