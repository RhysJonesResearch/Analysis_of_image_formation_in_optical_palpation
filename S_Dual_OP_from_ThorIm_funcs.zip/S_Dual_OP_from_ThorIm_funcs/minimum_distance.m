function [minDist, min_p_idx, min_q_idx] = minimum_distance(P, Q)
% Finds the minimum distance between points in P and points in Q

sP = size(P); sQ = size(Q);

if ~(sP(2)==sQ(2))
    error('Inputs P and Q must have the same number of columns')
end

% Initialise our minimum distance
minDist = realmax('double');

% loop through all points in P looking for maxes
for p = 1:sP(1)
    % calculate the minimum distance from points in P to Q
    [minP, q_idx] = min(sum( bsxfun(@minus, P(p,:), Q).^2, 2, 'double'));
    if minP < minDist
        % we've discovered a new largest minimum for P
        minDist = minP;
        % points in p and q corresponding to this minimum distance
        min_p_idx = p;
        min_q_idx = q_idx;
    end
end

% convert to euclidean distance
minDist = sqrt(minDist);

end
