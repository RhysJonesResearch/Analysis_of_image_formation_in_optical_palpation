function [magGrad, orGrad] = canny_stage1(img, sigma, det_neg_grad)
%% [magGrad, orGrad] = canny_stage1(img, sigma)
% Rhys edit: smooth dy before getting magrad to reduce likelihood of
% detecting horizontal bright lines in uniform background as edges.
% Implements the first stage of the Canny edge detector, by smoothing
% the image with a Gaussian filter of standard deviation sigma pixels,
% and returning the magnitude of the detected edge gradient, and the
% orientation of the edge gradient in degrees from the x-axis (-180 ->
% 180).
%
% Note, based on Matlab's implementation in edge.m

% figure
% imagesc(img);
% caxis('auto');
% colorbar;
% colormap gray

%figure
%histogram(reshape(img.',1,[]));
img = img .* (img < 50) + mean(mean(img)) .* (img > 50) ;        % REMOVES BRIGHT LINES 

% RHYS RANDOM TEST
img = medfilt2(img,[4 4]);
img = imgaussfilt(img,[4 4]); % GET RID OF OR FIND WAY TO USE ALL THIS
img = medfilt2(img,[4 4]);
%img = imbinarize(img,median(reshape(img.',1,[])));
%img = imgaussfilt(img,[2 1]);
%img = imgaussfilt(img,[2 1]);

%figure
%histogram(reshape(img.',1,[]));
% figure
% imagesc(img);
% caxis('auto');
% colorbar;
% colormap gray

% Calculate the gradients using the first derivative of gaussian filters
[dx, dy] = smoothGradient(img, sigma);

% Smooth dy to reduce likelihood of detecting horizontal bright lines in
% uniform background as edges
if det_neg_grad == 1
    %[~, dy2] = smoothGradient(dy, 1);
    dy = -dy;
    % Clip to the specified range.
    dy(dy < 0) = 0;
    dy = imgaussfilt(dy,[1 2]);
end

% figure
% imagesc(dy);
% caxis('auto');
% colorbar;
% colormap gray

if det_neg_grad == -1
    % dy = imgaussfilt(dy,[2 1]);
    %dy = medfilt2(dy,[3 1]);
    %h = [0.25; 0.25; 0.25; 0.25];
    %dy = conv2(dy,h,'same');
end

% DEBUG
% figure
% imagesc(dx);
% caxis('auto');
% colorbar;
% colormap gray
% 
% figure
% imagesc(dy);
% caxis('auto');
% colorbar;
% colormap gray


% Calculate Magnitude of Gradient
magGrad = hypot(dx, dy);

% % DEBUG
% figure
% imagesc(magGrad);
% caxis('auto');
% colorbar;
% colormap gray

% Find edge orientation between 0 and 180 degrees anticlockwise from the
% x-axis. +- 90deg indicates a vertical edge. +90 indicates an edge
% going from low (above) to high (below) intensity, which is what we're
% after.
orGrad = atan2d(dy, dx);

% % DEBUG
% figure
% imagesc(orGrad);
% caxis('auto');
% colorbar;
end

%% LOCAL FUNCTIONS
function [GX, GY] = smoothGradient(I, sigma)
%% [GX, GY] = smoothGradient(I, sigma)
% Local function, apply the smoothing gaussian filters to the image,
% then calculate the edge strength in the Y and X directions.

% Create an even-length 1-D separable Derivative of Gaussian filter

% Determine filter length
filterLength = 8*ceil(sigma);
n = (filterLength - 1)/2;
x = -n:n;

% Create 1-D Gaussian Kernel
c = 1/(sqrt(2*pi)*sigma);
gaussKernel = c * exp(-(x.^2)/(2*sigma^2));

% Normalize to ensure kernel sums to one
gaussKernel = gaussKernel/sum(gaussKernel);

% Create 1-D Derivative of Gaussian Kernel
derivGaussKernel = gradient(gaussKernel);

% Normalize to ensure kernel sums to zero
negVals = derivGaussKernel < 0;
posVals = derivGaussKernel > 0;
derivGaussKernel(posVals) = derivGaussKernel(posVals)/sum(derivGaussKernel(posVals));
derivGaussKernel(negVals) = derivGaussKernel(negVals)/abs(sum(derivGaussKernel(negVals)));

% Compute smoothed numerical gradient of image I along x (horizontal)
% direction. GX corresponds to dG/dx, where G is the Gaussian Smoothed
% version of image I.
GX = imfilter(I, gaussKernel', 'conv', 'replicate');
GX = imfilter(GX, derivGaussKernel, 'conv', 'replicate');

% Compute smoothed numerical gradient of image I along y (vertical)
% direction. GY corresponds to dG/dy, where G is the Gaussian Smoothed
% version of image I.
GY = imfilter(I, gaussKernel, 'conv', 'replicate');
GY  = imfilter(GY, derivGaussKernel', 'conv', 'replicate');
end