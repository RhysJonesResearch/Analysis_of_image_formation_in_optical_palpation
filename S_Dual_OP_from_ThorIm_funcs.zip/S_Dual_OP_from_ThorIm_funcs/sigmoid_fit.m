function LayerThickness_x = sigmoid_fit(img, config, UorC)
%% Goal - Fit sigmoid to edge to find transition pixel insteda of using Canny stages 1 and 2
%%
if UorC == 0
    Z_u = config.EXTENT_Z_u(1);
    Z_l = config.EXTENT_Z_u(2);
else
    Z_u = config.EXTENT_Z_c(1);
    Z_l = config.EXTENT_Z_c(2);
end
cutoff = 12;

LayerThickness_x = zeros([size(img,1),1]);

img_z = img(Z_u:Z_l,:);

% logical = img_z < mean(config.OCT_MIN_DB_RANGE);
% img_z(logical) = mean(config.OCT_MIN_DB_RANGE);

img_z = imgaussfilt(img_z,[1 5]);
img_z = medfilt2(img_z,[3 3]);
img_z = imgaussfilt(img_z,[1 3]);
% img = imgaussfilt(img,[1 3]);
% img = medfilt2(img,[5 5],'symmetric');
% img = imsharpen(img,'Radius',2,'Amount',0.1);
% img = medfilt2(img,[3 3],'symmetric');
%img_z = medfilt2(img_z,[5 5]);

[N,edges] = histcounts(img_z,100);
x_s = double((edges(1:end-1)+edges(2:end))/2);
N = double(N);
[~,locs,~,~] = findpeaks(N,x_s,'SortStr','descend');
peaks_T = [locs(1), locs(2)];
PixNum = 1:Z_l-Z_u-cutoff+1;
% PixNum = 1:Z_l-Z_u-cutoff+1;
% %step = [zeros(1,floor(size(PixNum,2)/2))+min(peaks),zeros(1,ceil(size(PixNum,2)/2))+max(peaks)];
% step = [zeros(1,floor(size(PixNum,2)*2))+min(peaks),zeros(1,ceil(size(PixNum,2)*2))+max(peaks)];

for n2 = 1:size(img_z,2)
    col = img_z(1:end-cutoff,n2);
    
%     figure
%     histogram(reshape(img.',1,[]));
%     hold on
    [N,edges] = histcounts(col,100);
    x_s = double((edges(1:end-1)+edges(2:end))/2);
    %N = double(medfilt1(N,5));
    N = double(imgaussfilt(N,config.HistFilt));
%     plot(x_s,N*1240)
%     figure
%     findpeaks([0,N],[0,x_s],'Annotate','extents')
    [~,locs,~,~] = findpeaks([0,N,0],[min(x_s)-1,x_s,max(x_s)+1],'SortStr','descend','MinPeakProminence',1.0);
    if size(locs,2) >=2 && abs(locs(1)-locs(2)) > 1.5
        peaks = [locs(1), locs(2)];
    elseif size(locs,2) >=3 && abs(locs(1)-locs(3)) > 1.5
        peaks = [locs(1), locs(3)];
    elseif size(locs,2) >=4 && abs(locs(1)-locs(4)) > 1.5
        peaks = [locs(1), locs(4)];
    elseif n2 > 1
        % do nothing and hence set to previous peaks values
    else
        peaks = peaks_T;
    end
%     meanpeaks = mean(peaks);
%     minpeaks = min(peaks);
%     maxpeaks = max(peaks);
%     step = [zeros(1,floor(size(PixNum,2)*2))+minpeaks,zeros(1,5)+maxpeaks+config.InterfacePeak*(maxpeaks-minpeaks),zeros(1,ceil(size(PixNum,2)*2)-5)+maxpeaks];
%     %col(col<minpeaks) = minpeaks;
%     %col(col>maxpeaks) = maxpeaks;
%     %[r,lags] = xcorr(col-meanpeaks,step-meanpeaks);
%     col2 = [zeros(floor(size(PixNum,2)/2),1)+min(peaks);col;zeros(floor(size(PixNum,2)/2),1)+max(peaks)];
%     [r,lags] = xcorr(col2-meanpeaks-config.CorrelationBias*(maxpeaks-minpeaks),step-meanpeaks-config.CorrelationBias*(maxpeaks-minpeaks));
%     [~, idx] = max(r);
%     %EdgePix = lags(idx)+floor(size(PixNum,2)/2);
%     %LayerThickness_x(n2) = Z_u+floor(size(PixNum,2)/2 + lags(idx));
%     LayerThickness_x(n2) = Z_u + floor(size(PixNum,2)*3/2) + lags(idx);
    
    step = [zeros(1,floor(size(PixNum,2))-config.InterFlatW)+min(peaks),zeros(1,config.InterFlatW)+min(peaks)+config.InterFlatM*(max(peaks)-min(peaks)),zeros(1,config.InterfacePeakW)+max(peaks)+config.InterfacePeakM*(max(peaks)-min(peaks)),zeros(1,ceil(size(PixNum,2))-config.InterfacePeakW)+max(peaks)];
    col2 = [zeros(1,floor(size(PixNum,2)*2))+min(peaks),col',zeros(1,floor(size(PixNum,2)*2))+max(peaks)];
    [r,lags] = xcorr(col2-mean(peaks),step-mean(peaks));
    [~, idx] = max(r);
    LayerThickness_x(n2) = Z_u - floor(size(PixNum,2)) + lags(idx);
end

figure
imagesc(img)
caxis('auto');
colorbar;
colormap gray;
hold on;
plot(LayerThickness_x, 'r-');


% % figure
% % plot(gradient(LayerThickness_x));
% % hold on
% LayerThickness_f = imgaussfilt(LayerThickness_x,[3 1]);
% % plot(gradient(LayerThickness_f));
% %plot(abs(gradient(LayerThickness_x)) > 0.55);
% %plot(imgaussfilt(int8(abs(gradient(LayerThickness_x)) > 0.55)*10,[6 1]) > 0.55);
% 
% % figure
% % plot(LayerThickness_x);
% % hold on
% % plot(LayerThickness_f)
% for n = 1:1
%     logical = imgaussfilt(int8(abs(gradient(LayerThickness_f)) > 0.35)*10,[6 1]) > 0.55;
%     LayerThickness_f(logical) = NaN;
%     y_int = 1:length(LayerThickness_f);
%     LayerThickness_f(isnan(LayerThickness_f)) = interp1(y_int(~isnan(LayerThickness_f)),LayerThickness_f(~isnan(LayerThickness_f)),y_int(isnan(LayerThickness_f)),'spline','extrap'); %, 'spline');
% end
% % plot(LayerThickness_f);
% LayerThickness_x = round(LayerThickness_f);
% % plot(LayerThickness_x);
% 
% figure
% imagesc(img)
% caxis('auto');
% colorbar;
% colormap gray;
% hold on;
% plot(LayerThickness_x, 'r-');

end